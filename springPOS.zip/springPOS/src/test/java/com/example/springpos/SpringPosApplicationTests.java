package com.example.springpos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPosApplicationTests {

    @Test
    void contextLoads() {
    }

}
